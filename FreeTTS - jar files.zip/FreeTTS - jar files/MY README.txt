The jar name : "FreeTTS _ speakers name _ speed of emphsis"

jar args: 1) file destination.  2) sentence string.

NOTE: 'lib' folder must be in the same directory as the jar. 